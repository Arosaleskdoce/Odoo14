# -*- coding: utf-8 -*-

from . import management
from . import res_partner
from . import user