This module validates phone numbers in the Attendee form of the *Event* module, just like the
*phone_validation* module valide phone numbers in the Partner form. It also adds phone number lookup on attendees on incoming calls.
