# l10n_cl_import_bank_statement_line
Import Chilean Bank Statement Lines from Excel/CSV file
