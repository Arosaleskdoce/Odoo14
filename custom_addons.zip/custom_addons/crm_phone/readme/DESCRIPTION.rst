This module is an extension of the *base_phone* module for CRM. It also restores the crm.phonecall object which has been moved from Odoo Community to Odoo Enterprise in Odoo v9.
