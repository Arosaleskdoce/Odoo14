from . import crm_phonecall
from . import crm_lead
from . import res_partner
from . import res_users
from . import phone_common
