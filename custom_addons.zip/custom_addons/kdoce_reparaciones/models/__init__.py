# -*- coding: utf-8 -*-

from . import reparacion
from . import res_partner
from . import user